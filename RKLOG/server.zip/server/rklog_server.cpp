
#include <iostream>

#include "rpc/server.h"
#include "rklog_server.h"


static rpc::server* psrv;

//start log server
int rklog_serv_start(RklogServer& log, const char* serverip, unsigned short serverport)
{
    psrv = new rpc::server(serverip, serverport);
    
    psrv->bind("LogInfo", [&log](const string & source, string const & info) { log.LogInfo(source, info); });
    psrv->bind("LogError", [&log](const string & source, string const & info) { log.LogError(source, info); });
    psrv->bind("LogWarning", [&log](const string & source, string const & info) { log.LogWarning(source, info); });
    psrv->bind("LogDebug", [&log](const string & source, string const & info) { log.LogDebug(source, info); });

    psrv->async_run();

    return 0;
}

//stop log server
int rklog_serv_stop()
{
    if(psrv)
    {
        psrv->close_sessions();
        psrv->stop();
        delete psrv;
        psrv = nullptr;
    }

    return 0;
}

RklogServer::RklogServer():_infos(100)
{

}

RklogServer::~RklogServer()
{

}

//hook out function
void RklogServer::HookOut(void (*outhook)(ReaderWriterQueue<RkLogInfo>&))
{
    _OutHook = outhook;
}

//log out
inline void RklogServer::Log(const string & itype, const string & source, const string & info)
{
    RkLogInfo loginfo = 
    {
        .itype = itype,
        .source = source,
        .info = info
    };

    if(_OutHook)
    {
        _infos.try_enqueue(loginfo);
        _OutHook(_infos);        
    }
    else
        std::cout<<loginfo.itype<<"@"<<loginfo.source<<"> "<<loginfo.info<<std::endl;
}


void RklogServer::LogInfo(const string & source, const string& info)
{
    Log(RKLOG_INFO_KEY, source, info);
}

void RklogServer::LogError(const string & source, const string& info)
{
    Log(RKLOG_ERROR_KEY, source, info);
}

void RklogServer::LogWarning(const string & source, const string& info)
{
    Log(RKLOG_WARNING_KEY, source, info);
}

void RklogServer::LogDebug(const string & source, const string& info)
{
    Log(RKLOG_DEBUG_KEY, source, info);
}


