
#include <string>


//#include "node_modules/nan/nan.h"
#include <nan.h>
#include "rklog_server.h"
#include "readerwriterqueue.h"

using namespace std;

static Nan::Callback * __outcb;
static RklogServer __logsrv;
static uv_async_t __handle;


//send log info to js
void OnLogOut(uv_async_t* handle)
{
    if(__outcb)
    {
        Nan::HandleScope scope;
        auto infos = (ReaderWriterQueue<RkLogInfo> *)handle->data;
        RkLogInfo info;
        while(infos->try_dequeue(info))
        {
            v8::Local<v8::Value> argv[] = {
                Nan::New(info.itype.c_str()).ToLocalChecked(),
                Nan::New(info.source.c_str()).ToLocalChecked(),
                Nan::New(info.info.c_str()).ToLocalChecked()
            };
            Nan::Call(*__outcb, 3, argv);
        }
    }
}

//recv log info from net
void LogOutEvent(ReaderWriterQueue<RkLogInfo>& infos)
{
    __handle.data = &infos;
    uv_async_send(&__handle);
}

//start log server
void StartLogServer(const Nan::FunctionCallbackInfo<v8::Value>& info)
{
    if (info.Length() < 3) 
    {
        Nan::ThrowTypeError("Wrong number of arguments");
        return;
    }

    if (!info[0]->IsString() || !info[1]->IsNumber() || !info[2]->IsFunction()) 
    {
        Nan::ThrowTypeError("Wrong arguments");
        return;
    }

    __outcb = new Nan::Callback(info[2].As<v8::Function>());
    uv_async_init(uv_default_loop(), &__handle, OnLogOut);
    __logsrv.HookOut(LogOutEvent);
    
    v8::String::Utf8Value ip(info[0]->ToString());
    rklog_serv_start(__logsrv, *ip, info[1]->Int32Value());
}

//stop log server
void StopLogServer(const Nan::FunctionCallbackInfo<v8::Value>& info)
{
    rklog_serv_stop();
    uv_close((uv_handle_t*)&__handle, nullptr);

    if(__outcb)
    {
        delete __outcb;
        __outcb = nullptr;
    }
}

void Init(v8::Local<v8::Object> exports) 
{
    exports->Set(Nan::New("StartLogServer").ToLocalChecked(), Nan::New<v8::FunctionTemplate>(StartLogServer)->GetFunction());
    exports->Set(Nan::New("StopLogServer").ToLocalChecked(), Nan::New<v8::FunctionTemplate>(StopLogServer)->GetFunction());
}


NODE_MODULE(rklog_server, Init)